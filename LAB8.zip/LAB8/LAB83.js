import { Button, FlatList, StyleSheet, Text, TextInput, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import {doc,collection,addDoc,updateDoc,deleteDoc, onSnapshot, snapshotEqual} from 'firebase/firestore'
import {FIRESTORE_DB} from './firebaseconfig'

const ITEMS_COLLECTION = collection(FIRESTORE_DB,'items')

const LAB83 = () => {
    const [text, setText] = useState('');
    const [items, setItems] = useState([]);
    useEffect(()=>{
        const unsubcribe = onSnapshot(ITEMS_COLLECTION,(snapshot)=>{
            const updatedItems = [];
            snapshot.forEach((doc)=>{
                updatedItems.push({id:doc.id,...doc.data()})
            })
            setItems(updatedItems);
        })
        return ()=>unsubcribe();
    },[])
    const handleData = async()=>{
        try {
            await addDoc(ITEMS_COLLECTION,{
                text:text
            })

        } catch (error) {
            console.error(error)
        }
    }
    const handleDelete = async(itemId)=>{
        try {
            const itemDoc = doc(FIRESTORE_DB,'items',itemId)
             await deleteDoc(itemDoc);
        } catch (error) {
            console.error(error)
        }
    }
    const renderItem = ({item})=>{
        return(
            <View style={{flexDirection:'row',justifyContent:'center',alignItems:'center'}}>
               <Text>{item.text} - {item.id}</Text>
                <Button title='Delete' onPress={()=>handleDelete(item.id)}/>
            </View>
        )
    }
  return (
    <View style={{flex:1}}>
        <TextInput 
        placeholder='Nhap text'
        value={text} onChangeText={setText}
        />
        <Button title='Thêm' onPress={handleData}/>
        <FlatList data={items}
        renderItem={renderItem}
        keyExtractor={(item)=>item.id}
        />
    </View>
  )
}

export default LAB83

const styles = StyleSheet.create({})