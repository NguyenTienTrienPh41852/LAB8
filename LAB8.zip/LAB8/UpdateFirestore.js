import React, { useState } from "react";
import { Button, TextInput, View } from "react-native";
import {doc, updateDoc} from 'firebase/firestore';
import {FIRESTORE_DB} from './firebaseconfig';
const AppLAB82= ()=>{
    const [text, setText] = useState('');
    const [id, setId] = useState('')
    const handleUpdate = async(itemId,newText)=>{
        try {
            // itemId = '';
            const itemDoc = doc(FIRESTORE_DB,'SinhVien',itemId);
            await updateDoc(itemDoc,{text:newText})
           console.log("Tài liệu được cập nhật id="+itemDoc.id)
           setText('') 
        } catch (error) {
            console.log("Lỗi cập nhật"+error)
        }
    }
return(
    <View>
        <TextInput placeholder="Nhap id" value={id} onChangeText={setId}/>
        <TextInput placeholder="Nhap ten SV" value={text} onChangeText={setText}/>
        <Button title="update" onPress={()=>handleUpdate(id,text)}/>
    </View>
)
}
export default AppLAB82;