// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";

import { getAnalytics } from "firebase/analytics";
import {getAuth,signOut,getRedirectResult,signInWithRedirect,createUserWithEmailAndPassword,signInWithEmailAndPassword,GoogleAuthProvider} from 'firebase/auth'
import {getFirestore} from 'firebase/firestore'
import {getDatabase} from 'firebase/database'
import {getStorage} from 'firebase/storage'
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional



const firebaseConfig = {
  apiKey: "AIzaSyBA44qGTkfseEGTCZvADxR5jQzSQi-DwS0",
  authDomain: "lab7-61bcf.firebaseapp.com",
  projectId: "lab7-61bcf",
  storageBucket: "lab7-61bcf.appspot.com",
  messagingSenderId: "14515411776",
  appId: "1:14515411776:web:17be60ceb4545bceef78a5",
  measurementId: "G-PTJBDE8JVF"
};

// Initialize Firebase
export const FIREBASE_APP = initializeApp(firebaseConfig);
export const FIREBASE_AUTH = getAuth(FIREBASE_APP);
export const FIRESTORE_DB = getFirestore(FIREBASE_APP)
export const CREATE_EMAIL = async (email, password) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(FIREBASE_AUTH, email, password);
    // Trả về thông tin của user nếu đăng ký thành công
    return userCredential.user;
  } catch (error) {
    // Xử lý lỗi nếu có
    throw error;
  }
};

export const SIGNIN_EMAIL = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(FIREBASE_AUTH, email, password);
    // Trả về thông tin của user nếu đăng nhập thành công
    return userCredential.user;
  } catch (error) {
    // Xử lý lỗi nếu có
    throw error;
  }
};
const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/contacts.readonly');
provider.setCustomParameters({
  'login_hint': 'trienntph41852@fpt.edu.vn'
});

export const SIGNIN_GOOGLE = async () => {
  try {
    const open = await signInWithRedirect(FIREBASE_AUTH, provider);
    return open;
  } catch (error) {
    throw error;
  }
};
export const SIGNOUT_GOOGLE = async()=>{
  try {
    const signout = await  signOut(FIREBASE_AUTH)
  } catch (error) {
    throw error
  }
}
export const DATABASE = getDatabase(FIREBASE_APP);
export const STORAGE = getStorage(FIREBASE_APP);



const analytics = getAnalytics(FIREBASE_APP);